﻿namespace EMicroservices.IDP.Presentation
{
    public static class AssemblyReference
    {
    }
}
